from typing import Optional, List, Union

class forwardMessages:
    """forwardMessages"""

    pass
