from typing import Optional, List, Union

class editForumTopic:
    """editForumTopic"""

    pass
