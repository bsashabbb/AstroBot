from typing import Optional, List, Union

class reopenGeneralForumTopic:
    """reopenGeneralForumTopic"""

    pass
