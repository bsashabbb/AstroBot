from typing import Optional, List, Union

class setCustomEmojiStickerSetThumbnail:
    """setCustomEmojiStickerSetThumbnail"""

    pass
