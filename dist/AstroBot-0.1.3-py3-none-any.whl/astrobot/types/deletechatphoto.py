from typing import Optional, List, Union

class deleteChatPhoto:
    """deleteChatPhoto"""

    pass
