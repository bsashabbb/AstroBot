from typing import Optional, List, Union

class getUpdates:
    """getUpdates"""

    pass
