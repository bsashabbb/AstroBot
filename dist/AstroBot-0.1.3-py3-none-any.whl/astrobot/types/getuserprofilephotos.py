from typing import Optional, List, Union

class getUserProfilePhotos:
    """getUserProfilePhotos"""

    pass
