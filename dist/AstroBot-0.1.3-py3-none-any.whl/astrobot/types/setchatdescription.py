from typing import Optional, List, Union

class setChatDescription:
    """setChatDescription"""

    pass
