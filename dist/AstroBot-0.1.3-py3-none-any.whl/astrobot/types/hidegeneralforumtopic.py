from typing import Optional, List, Union

class hideGeneralForumTopic:
    """hideGeneralForumTopic"""

    pass
