from typing import Optional, List, Union

class deleteMessage:
    """deleteMessage"""

    pass
