from typing import Optional, List, Union

class answerInlineQuery:
    """answerInlineQuery"""

    pass
