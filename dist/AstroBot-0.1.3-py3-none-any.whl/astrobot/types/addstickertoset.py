from typing import Optional, List, Union

class addStickerToSet:
    """addStickerToSet"""

    pass
