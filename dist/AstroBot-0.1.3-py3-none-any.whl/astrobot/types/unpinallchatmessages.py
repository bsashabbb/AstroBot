from typing import Optional, List, Union

class unpinAllChatMessages:
    """unpinAllChatMessages"""

    pass
