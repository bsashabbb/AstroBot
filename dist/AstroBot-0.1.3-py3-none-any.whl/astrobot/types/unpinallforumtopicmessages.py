from typing import Optional, List, Union

class unpinAllForumTopicMessages:
    """unpinAllForumTopicMessages"""

    pass
