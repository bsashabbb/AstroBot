from typing import Optional, List, Union

class pinChatMessage:
    """pinChatMessage"""

    pass
