from typing import Optional, List, Union

class setWebhook:
    """setWebhook"""

    pass
