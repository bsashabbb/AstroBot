from typing import Optional, List, Union

class sendDice:
    """sendDice"""

    pass
