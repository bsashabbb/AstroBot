from typing import Optional, List, Union

class stopMessageLiveLocation:
    """stopMessageLiveLocation"""

    pass
