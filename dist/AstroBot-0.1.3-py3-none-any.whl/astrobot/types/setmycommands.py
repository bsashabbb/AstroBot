from typing import Optional, List, Union

class setMyCommands:
    """setMyCommands"""

    pass
