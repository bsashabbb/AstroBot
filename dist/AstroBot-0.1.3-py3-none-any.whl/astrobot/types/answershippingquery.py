from typing import Optional, List, Union

class answerShippingQuery:
    """answerShippingQuery"""

    pass
