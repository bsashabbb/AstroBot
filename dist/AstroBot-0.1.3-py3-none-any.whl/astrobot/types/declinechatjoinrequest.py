from typing import Optional, List, Union

class declineChatJoinRequest:
    """declineChatJoinRequest"""

    pass
