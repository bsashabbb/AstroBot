from typing import Optional, List, Union

class removeUserVerification:
    """removeUserVerification"""

    pass
