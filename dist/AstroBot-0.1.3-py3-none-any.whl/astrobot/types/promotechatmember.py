from typing import Optional, List, Union

class promoteChatMember:
    """promoteChatMember"""

    pass
