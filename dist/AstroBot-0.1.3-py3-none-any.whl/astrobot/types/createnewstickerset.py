from typing import Optional, List, Union

class createNewStickerSet:
    """createNewStickerSet"""

    pass
