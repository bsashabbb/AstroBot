from typing import Optional, List, Union

class setStickerEmojiList:
    """setStickerEmojiList"""

    pass
