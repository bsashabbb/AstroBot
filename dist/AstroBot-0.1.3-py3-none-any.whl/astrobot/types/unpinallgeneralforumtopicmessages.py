from typing import Optional, List, Union

class unpinAllGeneralForumTopicMessages:
    """unpinAllGeneralForumTopicMessages"""

    pass
