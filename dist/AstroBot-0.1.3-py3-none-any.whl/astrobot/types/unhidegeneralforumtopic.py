from typing import Optional, List, Union

class unhideGeneralForumTopic:
    """unhideGeneralForumTopic"""

    pass
