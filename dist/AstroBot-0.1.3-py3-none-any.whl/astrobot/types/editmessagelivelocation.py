from typing import Optional, List, Union

class editMessageLiveLocation:
    """editMessageLiveLocation"""

    pass
