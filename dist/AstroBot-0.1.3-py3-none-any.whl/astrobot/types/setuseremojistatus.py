from typing import Optional, List, Union

class setUserEmojiStatus:
    """setUserEmojiStatus"""

    pass
