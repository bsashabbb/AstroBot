from typing import Optional, List, Union

class getStarTransactions:
    """getStarTransactions"""

    pass
