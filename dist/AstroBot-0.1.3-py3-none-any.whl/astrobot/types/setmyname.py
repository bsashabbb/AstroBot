from typing import Optional, List, Union

class setMyName:
    """setMyName"""

    pass
