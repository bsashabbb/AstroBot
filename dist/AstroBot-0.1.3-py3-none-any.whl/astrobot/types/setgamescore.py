from typing import Optional, List, Union

class setGameScore:
    """setGameScore"""

    pass
