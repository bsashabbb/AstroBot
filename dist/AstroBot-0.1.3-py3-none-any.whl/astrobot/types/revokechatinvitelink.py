from typing import Optional, List, Union

class revokeChatInviteLink:
    """revokeChatInviteLink"""

    pass
