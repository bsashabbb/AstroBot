from typing import Optional, List, Union

class editMessageCaption:
    """editMessageCaption"""

    pass
