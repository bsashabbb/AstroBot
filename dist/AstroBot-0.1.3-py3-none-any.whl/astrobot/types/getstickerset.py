from typing import Optional, List, Union

class getStickerSet:
    """getStickerSet"""

    pass
