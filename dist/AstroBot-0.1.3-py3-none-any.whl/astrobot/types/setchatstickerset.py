from typing import Optional, List, Union

class setChatStickerSet:
    """setChatStickerSet"""

    pass
