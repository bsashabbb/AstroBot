from typing import Optional, List, Union

class savePreparedInlineMessage:
    """savePreparedInlineMessage"""

    pass
