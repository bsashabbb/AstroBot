from typing import Optional, List, Union

class getMyDescription:
    """getMyDescription"""

    pass
