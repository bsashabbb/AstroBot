from typing import Optional, List, Union

class getChatMemberCount:
    """getChatMemberCount"""

    pass
