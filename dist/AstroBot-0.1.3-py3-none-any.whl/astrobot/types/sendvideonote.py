from typing import Optional, List, Union

class sendVideoNote:
    """sendVideoNote"""

    pass
