from typing import Optional, List, Union

class setStickerSetThumbnail:
    """setStickerSetThumbnail"""

    pass
