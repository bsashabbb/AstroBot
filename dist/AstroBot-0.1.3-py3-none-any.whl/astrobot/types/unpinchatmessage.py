from typing import Optional, List, Union

class unpinChatMessage:
    """unpinChatMessage"""

    pass
