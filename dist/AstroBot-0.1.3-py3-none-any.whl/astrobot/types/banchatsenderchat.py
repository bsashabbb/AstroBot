from typing import Optional, List, Union

class banChatSenderChat:
    """banChatSenderChat"""

    pass
