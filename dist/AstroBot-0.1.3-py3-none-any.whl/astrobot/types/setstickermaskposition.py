from typing import Optional, List, Union

class setStickerMaskPosition:
    """setStickerMaskPosition"""

    pass
