from typing import Optional, List, Union

class sendChatAction:
    """sendChatAction"""

    pass
