from typing import Optional, List, Union

class editMessageMedia:
    """editMessageMedia"""

    pass
