from typing import Optional, List, Union

class refundStarPayment:
    """refundStarPayment"""

    pass
