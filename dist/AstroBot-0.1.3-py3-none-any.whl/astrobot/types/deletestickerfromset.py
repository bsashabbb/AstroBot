from typing import Optional, List, Union

class deleteStickerFromSet:
    """deleteStickerFromSet"""

    pass
