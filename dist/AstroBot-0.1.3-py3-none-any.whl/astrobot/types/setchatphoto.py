from typing import Optional, List, Union

class setChatPhoto:
    """setChatPhoto"""

    pass
