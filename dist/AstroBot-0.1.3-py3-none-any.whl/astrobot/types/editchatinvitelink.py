from typing import Optional, List, Union

class editChatInviteLink:
    """editChatInviteLink"""

    pass
