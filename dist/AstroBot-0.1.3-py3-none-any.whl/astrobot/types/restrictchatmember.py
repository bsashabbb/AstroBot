from typing import Optional, List, Union

class restrictChatMember:
    """restrictChatMember"""

    pass
