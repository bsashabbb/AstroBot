from typing import Optional, List, Union

class setStickerSetTitle:
    """setStickerSetTitle"""

    pass
