from typing import Optional, List, Union

class banChatMember:
    """banChatMember"""

    pass
