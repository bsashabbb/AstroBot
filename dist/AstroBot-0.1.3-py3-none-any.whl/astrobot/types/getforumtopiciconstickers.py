from typing import Optional, List, Union

class getForumTopicIconStickers:
    """getForumTopicIconStickers"""

    pass
