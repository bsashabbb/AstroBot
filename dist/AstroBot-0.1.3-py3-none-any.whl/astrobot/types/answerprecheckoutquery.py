from typing import Optional, List, Union

class answerPreCheckoutQuery:
    """answerPreCheckoutQuery"""

    pass
