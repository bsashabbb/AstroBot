from typing import Optional, List, Union

class getChatMenuButton:
    """getChatMenuButton"""

    pass
