from typing import Optional, List, Union

class logOut:
    """logOut"""

    pass
