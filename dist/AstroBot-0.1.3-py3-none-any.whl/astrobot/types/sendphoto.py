from typing import Optional, List, Union

class sendPhoto:
    """sendPhoto"""

    pass
