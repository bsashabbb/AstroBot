from typing import Optional, List, Union

class sendAnimation:
    """sendAnimation"""

    pass
