from typing import Optional, List, Union

class removeChatVerification:
    """removeChatVerification"""

    pass
