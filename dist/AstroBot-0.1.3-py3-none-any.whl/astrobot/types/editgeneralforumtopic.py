from typing import Optional, List, Union

class editGeneralForumTopic:
    """editGeneralForumTopic"""

    pass
