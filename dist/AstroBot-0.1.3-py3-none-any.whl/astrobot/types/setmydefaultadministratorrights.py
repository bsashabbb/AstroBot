from typing import Optional, List, Union

class setMyDefaultAdministratorRights:
    """setMyDefaultAdministratorRights"""

    pass
