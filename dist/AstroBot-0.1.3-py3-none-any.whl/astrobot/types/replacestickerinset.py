from typing import Optional, List, Union

class replaceStickerInSet:
    """replaceStickerInSet"""

    pass
