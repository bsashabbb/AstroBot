from typing import Optional, List, Union

class answerWebAppQuery:
    """answerWebAppQuery"""

    pass
