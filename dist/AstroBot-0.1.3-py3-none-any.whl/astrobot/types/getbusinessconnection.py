from typing import Optional, List, Union

class getBusinessConnection:
    """getBusinessConnection"""

    pass
