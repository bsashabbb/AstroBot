from typing import Optional, List, Union

class unbanChatSenderChat:
    """unbanChatSenderChat"""

    pass
