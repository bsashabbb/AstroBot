from typing import Optional, List, Union

class exportChatInviteLink:
    """exportChatInviteLink"""

    pass
