from typing import Optional, List, Union

class getMyName:
    """getMyName"""

    pass
