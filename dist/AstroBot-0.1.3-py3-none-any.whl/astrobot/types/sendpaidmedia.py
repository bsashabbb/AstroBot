from typing import Optional, List, Union

class sendPaidMedia:
    """sendPaidMedia"""

    pass
