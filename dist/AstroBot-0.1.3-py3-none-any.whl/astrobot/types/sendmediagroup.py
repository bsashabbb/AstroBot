from typing import Optional, List, Union

class sendMediaGroup:
    """sendMediaGroup"""

    pass
