from typing import Optional, List, Union

class createInvoiceLink:
    """createInvoiceLink"""

    pass
