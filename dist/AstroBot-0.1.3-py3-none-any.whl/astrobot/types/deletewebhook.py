from typing import Optional, List, Union

class deleteWebhook:
    """deleteWebhook"""

    pass
