from typing import Optional, List, Union

class setStickerKeywords:
    """setStickerKeywords"""

    pass
