from typing import Optional, List, Union

class getChatAdministrators:
    """getChatAdministrators"""

    pass
