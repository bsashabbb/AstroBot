from typing import Optional, List, Union

class setChatPermissions:
    """setChatPermissions"""

    pass
