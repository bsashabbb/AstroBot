from typing import Optional, List, Union

class deleteForumTopic:
    """deleteForumTopic"""

    pass
