from typing import Optional, List, Union

class CallbackGame:
    """CallbackGame"""

    pass
