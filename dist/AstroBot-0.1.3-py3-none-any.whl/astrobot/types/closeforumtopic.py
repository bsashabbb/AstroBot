from typing import Optional, List, Union

class closeForumTopic:
    """closeForumTopic"""

    pass
