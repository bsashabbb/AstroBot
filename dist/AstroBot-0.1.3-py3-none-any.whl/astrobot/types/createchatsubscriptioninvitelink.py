from typing import Optional, List, Union

class createChatSubscriptionInviteLink:
    """createChatSubscriptionInviteLink"""

    pass
