from typing import Optional, List, Union

class sendSticker:
    """sendSticker"""

    pass
