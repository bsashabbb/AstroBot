from typing import Optional, List, Union

class sendVoice:
    """sendVoice"""

    pass
