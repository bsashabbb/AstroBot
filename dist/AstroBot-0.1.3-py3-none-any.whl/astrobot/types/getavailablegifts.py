from typing import Optional, List, Union

class getAvailableGifts:
    """getAvailableGifts"""

    pass
