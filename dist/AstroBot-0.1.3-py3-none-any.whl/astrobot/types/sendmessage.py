from typing import Optional, List, Union

class sendMessage:
    """sendMessage"""

    pass
