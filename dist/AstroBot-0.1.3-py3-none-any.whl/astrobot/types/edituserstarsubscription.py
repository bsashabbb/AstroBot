from typing import Optional, List, Union

class editUserStarSubscription:
    """editUserStarSubscription"""

    pass
