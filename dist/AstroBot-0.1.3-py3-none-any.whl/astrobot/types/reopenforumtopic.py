from typing import Optional, List, Union

class reopenForumTopic:
    """reopenForumTopic"""

    pass
