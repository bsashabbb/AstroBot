from typing import Optional, List, Union

class deleteMyCommands:
    """deleteMyCommands"""

    pass
