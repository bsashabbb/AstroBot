from typing import Optional, List, Union

class setChatTitle:
    """setChatTitle"""

    pass
