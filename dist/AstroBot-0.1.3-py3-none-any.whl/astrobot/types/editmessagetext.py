from typing import Optional, List, Union

class editMessageText:
    """editMessageText"""

    pass
