from typing import Optional, List, Union

class copyMessage:
    """copyMessage"""

    pass
