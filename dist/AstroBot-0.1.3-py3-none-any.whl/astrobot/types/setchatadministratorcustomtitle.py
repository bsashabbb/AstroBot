from typing import Optional, List, Union

class setChatAdministratorCustomTitle:
    """setChatAdministratorCustomTitle"""

    pass
