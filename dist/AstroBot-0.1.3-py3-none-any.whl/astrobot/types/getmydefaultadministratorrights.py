from typing import Optional, List, Union

class getMyDefaultAdministratorRights:
    """getMyDefaultAdministratorRights"""

    pass
