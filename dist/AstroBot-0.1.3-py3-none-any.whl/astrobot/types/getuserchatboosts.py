from typing import Optional, List, Union

class getUserChatBoosts:
    """getUserChatBoosts"""

    pass
