from typing import Optional, List, Union

class stopPoll:
    """stopPoll"""

    pass
