from typing import Optional, List, Union

class setMessageReaction:
    """setMessageReaction"""

    pass
