from typing import Optional, List, Union

class deleteMessages:
    """deleteMessages"""

    pass
