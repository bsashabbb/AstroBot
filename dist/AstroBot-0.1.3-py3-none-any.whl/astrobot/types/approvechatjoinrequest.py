from typing import Optional, List, Union

class approveChatJoinRequest:
    """approveChatJoinRequest"""

    pass
