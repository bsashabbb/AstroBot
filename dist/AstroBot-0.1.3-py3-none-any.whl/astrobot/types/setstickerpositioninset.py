from typing import Optional, List, Union

class setStickerPositionInSet:
    """setStickerPositionInSet"""

    pass
