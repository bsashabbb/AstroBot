from typing import Optional, List, Union

class editMessageReplyMarkup:
    """editMessageReplyMarkup"""

    pass
