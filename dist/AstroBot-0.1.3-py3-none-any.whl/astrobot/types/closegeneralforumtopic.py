from typing import Optional, List, Union

class closeGeneralForumTopic:
    """closeGeneralForumTopic"""

    pass
