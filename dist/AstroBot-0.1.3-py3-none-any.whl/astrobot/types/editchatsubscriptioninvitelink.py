from typing import Optional, List, Union

class editChatSubscriptionInviteLink:
    """editChatSubscriptionInviteLink"""

    pass
