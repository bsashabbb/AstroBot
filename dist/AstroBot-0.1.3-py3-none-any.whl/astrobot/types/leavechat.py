from typing import Optional, List, Union

class leaveChat:
    """leaveChat"""

    pass
