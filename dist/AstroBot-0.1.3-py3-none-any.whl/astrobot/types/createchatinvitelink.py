from typing import Optional, List, Union

class createChatInviteLink:
    """createChatInviteLink"""

    pass
