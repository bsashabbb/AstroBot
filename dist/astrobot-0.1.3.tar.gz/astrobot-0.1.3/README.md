# AstroBot

Асинхронная библиотека для разработки Telegram ботов.

## Установка

~~~bash
pip install AstroBot
~~~

## Пример использования

~~~python
from astrobot import AstroBot

class MyBot(AstroBot):
    async def handle_start(self, update):
        if update.message and update.message.text == "/start":
            await self.send_message(update.message.chat.id, "Привет!")
~~~

## Лицензия

MIT